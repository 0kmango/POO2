
package ejercicio.pkg1;

import model.Persona;

public class Main {

    public static void main(String[] args) {
        
        System.out.println("Hola Mangos Hola Kiwis");
        
        Persona p = new Persona("Wacoldo", "22.345.772-k", 86);
        
        p.setNombre("Walcoldito Sanchez");

        System.out.println(p+"\n");
        System.out.println("El nombre de la persona es " + p.getNombre());
        System.out.println("La persona tiene " + p.getEdad() + " anhos");
        System.out.println("El rut de la persona es " + p.getRut() + "\n");
        
        p.imprimirNombre();
        
        System.out.println(Persona.EDAD_MINIMA);
        
        
        

        
    }
    
}
