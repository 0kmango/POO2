
package model;

public class Persona {
    
    //CONSTANTES
    public static final int EDAD_MINIMA = 18;
  
    //ATRIBUTOS
    private String nombre;
    private String rut;
    private int edad;

    //CONSTRUCTOR
    public Persona(String nombre, String rut, int edad) {
        this.nombre = nombre;
        this.rut = rut;
        this.edad = edad;
    }

    //GETTER Y SETTER
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    //TO STRING
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\nNombre: ").append(nombre);
        sb.append("\nRut: ").append(rut);
        sb.append("\nEdad: ").append(edad);
        return sb.toString();
    }
    
    //METODOS
    public void imprimirNombre(){
        System.out.println(this.nombre);
    }
    
    
    
    
    
    
}
