
package gestionpedidos;

import model.Cliente;
import model.Pedido;
import model.Producto;

public class Main {

    public static void main(String[] args) throws Exception {

        Cliente cli =  new Cliente("Wacoldo", "977765867", "casa 2 calle 3", true);
        Cliente cli2 =  new Cliente("Wacoldita", "981866524", "casa 1 calle 2", false);
        
        Producto prod = new Producto("Castanha", "JSU782H6", 10000);
        Producto prod2 = new Producto("Monopatin", "IJDIA9D292K", 40000);
        
        Pedido ped = new Pedido("JIA89J8S", cli, prod2, 10);
        Pedido ped2 = new Pedido("SANDAS89N", cli2, prod, 2);
        

        System.out.println(ped);
        System.out.println(ped2);

        ped.calcularTotal();
        
        

        
    }
    
}
