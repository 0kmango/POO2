
package model;

public class Producto {
        
        private String nombre;
        private String codProducto;
        private double precio;

    public Producto(String nombre, String codProducto, double precio) {
        this.nombre = nombre;
        this.codProducto = codProducto;
        this.precio = precio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) throws Exception {
        if(nombre != null || !nombre.isBlank())this.nombre = nombre;
        else throw new Exception("Ingrese nombre");
    }

    public String getCodProducto() {
        return codProducto;
    }

    public void setCodProducto(String codProducto) {
        if(codProducto.length() == 8)this.codProducto = codProducto;
        else throw new IllegalArgumentException("El codigo debe tener solo 8 caracteres.");
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) throws Exception {
        if(precio >= 0)this.precio = precio;
        else throw new Exception("Ingrese un valor valido");
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\nProducto: ").append((codProducto.length() == 8) ? codProducto : "Ingresa codigo valido");
        sb.append("\nNombre: ").append((nombre == null || nombre.isBlank()) ? "Ingresa Cliente" : nombre);
        sb.append("\nPrecio: $").append((precio <= 0) ? "Ingresa un valor valido" : precio);
        return sb.toString();
    }
        
        
    
        
        
    
}
