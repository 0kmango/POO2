
package model;

public class Pedido {
    
    private String codPedido;
    private Cliente cliente;
    private Producto producto;
    private int cantSolicitada;

    public Pedido(String codPedido, Cliente cliente, Producto producto, int cantSolicitada) throws Exception {
        this.codPedido = codPedido;
        this.cliente = cliente;
        this.producto = producto;
        this.cantSolicitada = cantSolicitada;
    }

    public String getCodPedido() {
        return codPedido;
    }

    public void setCodPedido(String codPedido) throws Exception {
        if(codPedido != null)this.codPedido = codPedido;
        else throw new Exception("Ingrese codigo.");
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public int getCantSolicitada() {
        return cantSolicitada;
    }

    public void setCantSolicitada(int cantSolicitada)throws Exception {
        if(cantSolicitada >= 0)this.cantSolicitada = cantSolicitada;
        else throw new Exception("Ingrese una cantidad valida.");
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\nPedido: ").append((codPedido == null || codPedido.isBlank()) ? "Ingrese codigo" : codPedido);
        sb.append(cliente);
        sb.append(producto);
        sb.append("\nCantidad Solicitada: ").append((cantSolicitada >= 0) ? cantSolicitada : "Indique cantidad.");
        return sb.toString();
    }
    
    
    
    public double calcularTotal(){
        double subTotal;
        subTotal = this.producto.getPrecio() * this.cantSolicitada;
        
        double subTotalDesc;
        if (subTotal > 180000){
               subTotalDesc = subTotal * 0.95;
        } else {
            subTotalDesc = subTotal;
        }
         
        double despacho;
        if(this.cliente.isZonaExtrema()== true){
            despacho = 15000;
        }else{
            despacho = 8000;
           }
        
        double totalFinal;
        totalFinal = subTotalDesc + despacho;
        
        return totalFinal; 
    }
    
    
}


