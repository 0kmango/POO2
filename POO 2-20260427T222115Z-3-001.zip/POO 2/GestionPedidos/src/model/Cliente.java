
package model;

public class Cliente {
    
    private String nombre;
    private String telefono;
    private String direccionDespacho;
    private boolean zonaExtrema;

    public Cliente(String nombre, String telefono, String direccionDespacho, boolean zonaExtrema) {
        this.nombre = nombre;
        this.telefono = telefono;
        this.direccionDespacho = direccionDespacho;
        this.zonaExtrema = zonaExtrema;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre)throws Exception {
        if(nombre != null || !nombre.isBlank())this.nombre = nombre;
        else throw new Exception("Ingrese nombre");
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono)throws Exception {
        if(telefono != null || !telefono.isBlank())this.telefono = telefono;
        else throw new Exception("Ingrese telefono");
    }

    public String getDireccionDespacho() {
        return direccionDespacho;
    }

    public void setDireccionDespacho(String direccionDespacho)throws Exception {
        if(direccionDespacho != null || !direccionDespacho.isBlank())this.direccionDespacho = direccionDespacho;
        else throw new Exception("Ingrese direccion");
    }

    public boolean isZonaExtrema() {
        return zonaExtrema;
    }

    public void setZonaExtrema(boolean zonaExtrema) {
        this.zonaExtrema = zonaExtrema;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\nCliente: ").append((nombre == null || nombre.isBlank()) ? "Ingresa Cliente" : nombre);
        sb.append("\nTelefono: ").append((telefono == null || telefono.isBlank()) ? "Ingresa telefono" : telefono);
        sb.append("\nDireccion Despacho: ").append((direccionDespacho == null || direccionDespacho.isBlank()) ? "Ingresa direccion" : direccionDespacho);
        sb.append("\nZona Extrema: ").append((zonaExtrema == true) ? "Pertenece a Zona Extrema" : "No pertenece a Zona Extrema");
        return sb.toString();
    }
    
    
    
    
}
