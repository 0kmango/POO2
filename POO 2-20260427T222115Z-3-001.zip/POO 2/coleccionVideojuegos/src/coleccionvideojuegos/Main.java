
package coleccionvideojuegos;

import model.Categoria;
import model.Videojuego;
import model.videojuegoDAO;

public class Main {

    public static void main(String[] args) {

        videojuegoDAO dao = new videojuegoDAO();
        
        Categoria cat1 = new Categoria("123", "Terror");
        Categoria cat2 = new Categoria("321", "Accion");
        
        
        Videojuego juego1 = new Videojuego("456", "POU", 2000, cat1, "123", "Terror");
        Videojuego juego2 = new Videojuego("543", "GTAV", 120000, cat2, "321", "Accion");
        
        
        // Agregar juegos a la lista
        dao.AgregarJuego(juego1);
        dao.AgregarJuego(juego2);
        
        
        // Mostrar cantidad
        int cantidad = dao.cantidadJuegos();
        System.out.println("Cantidad: " + cantidad);
        
        
        // Listar juegos
        dao.ListarJuegos();
        
        
        
        
    }
    
}
