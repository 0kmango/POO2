
package model;

public class Categoria {
 
    private String codigo;
    private String nombreCat;

    public Categoria(String codigo, String nombreCat) {
        this.codigo = codigo;
        this.nombreCat = nombreCat;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombreCat;
    }

    public void setNombre(String nombreCat) {
        this.nombreCat = nombreCat;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\nCodigo: ").append(codigo);
        sb.append("\nCategoria: ").append(nombreCat);
        return sb.toString();
    }
    
    
    
    
    
    
}
