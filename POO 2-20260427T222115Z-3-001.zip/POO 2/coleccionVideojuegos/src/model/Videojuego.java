package model;

public class Videojuego extends Categoria {
    
    private String id;
    private String nombre;
    private int precio;
    private Categoria categoria;

    public Videojuego(String id, String nombre, int precio, Categoria categoria, String codigo, String nombreCat) {
        super(codigo, nombre);
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
        this.categoria = categoria;
        
        setId(id);
        setNombre(nombre);
        setPrecio(precio);
        setCategoria(categoria);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Videojuego: ").append(id);
        sb.append("\nNombre: ").append(nombre);
        sb.append("\nPrecio: ").append(precio);
        return sb.toString();
    }
    
    
    
    
    
}
