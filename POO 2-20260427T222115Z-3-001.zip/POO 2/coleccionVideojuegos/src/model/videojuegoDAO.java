
package model;

import java.util.List;
import java.util.ArrayList;

public class videojuegoDAO {
    
   private List<Videojuego> ListaJuegos;
   
   
   // BUSCAR
    public videojuegoDAO(){
       ListaJuegos = new ArrayList<>();
    }

    public Videojuego BuscarJuego(String id){
        for (Videojuego juego : ListaJuegos) {
            if(juego.getId().equals(id)){
                return juego;
            }
        }   
           return null;
   }
    
    
    // AGREGAR
    public boolean AgregarJuego(Videojuego juego){
        if(juego == null){
            return false;
        }
        
        // validar que no existe el juego
        if(BuscarJuego(juego.getId()) != null){
            return false;
        }
        ListaJuegos.add(juego);
        return true;
    }
    
    
    // ELIMINAR
    public boolean EliminarJuego(String id){ //buscas por ID y eliminas el objeto
        for (Videojuego juego : ListaJuegos) { 
            if(juego.getId().equals(id)){
                ListaJuegos.remove(juego);
            }
        }
        return false;
    }
    
    
    // CANTIDAD DE ELEMENTOS
    public int cantidadJuegos(){ // no se agrega parametro, la lista sabe la cantidad
        int cantidad = ListaJuegos.size();
        return cantidad;
        
        //return ListaJuegos.size(); -- Igual a lo de arriba pero resumido
    }
    
    
    // LISTAR JUEGOS
    public void ListarJuegos(){
        if(ListaJuegos.size() == 0){ // preguntar si la lista esta vacia
            System.out.println("No hay nada en la lista");
    } else {
            for (Videojuego juego : ListaJuegos) {
                System.out.println("\nVideojuego id: " + juego.getId() +
                                   "\nNombre: " + juego.getNombre() +
                                   " " + juego.getCategoria());
            }
                
            }
        }
  
}
