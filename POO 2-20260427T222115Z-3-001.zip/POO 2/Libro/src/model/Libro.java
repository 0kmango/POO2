
package model;

public class Libro {
    
    private String titulo;
    private String escritor;
    private String coodISBN;
    private String editorial;
    private int anhoPublicacion;
    private double precioBase;

    public Libro(String titulo, String escritor, String coodISBN, String editorial, int anhoPublicacion, double precioBase) {
        this.titulo = titulo;
        this.escritor = escritor;
        this.coodISBN = coodISBN;
        this.editorial = editorial;
        this.anhoPublicacion = anhoPublicacion;
        this.precioBase = precioBase;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) throws Exception {
        if(!titulo.isBlank() && !titulo.isEmpty())this.titulo = titulo;
        else throw new Exception("El titulo no valido.");
    }

    public String getEscritor() {
        return escritor;
    }

    public void setEscritor(String escritor) throws Exception {
        if(!escritor.isBlank() && !escritor.isEmpty())this.escritor = escritor;
        else throw new Exception("Escritor no valido.");
    }

    public String getCoodISBN() {
        return coodISBN;
    }

    public void setCoodISBN(String coodISBN) {
        if(coodISBN.length() == 13)this.coodISBN = coodISBN;
        else throw new IllegalArgumentException("El codigo debe tener solo 13 caracteres.");
    }

    public String getEditorial() {
        return editorial;
    }

    public void setEditorial(String editorial) throws Exception {
        if(!editorial.isBlank() && !editorial.isEmpty())this.editorial = editorial;
        else throw new Exception("La editorial no puede estar vacio.");
    }

    public int getAnhoPublicacion() {
        return anhoPublicacion;
    }

    public void setAnhoPublicacion(int anhoPublicacion) throws Exception {
        if(anhoPublicacion > 0)this.anhoPublicacion = anhoPublicacion;
        else throw new Exception("El anh de publicacion debe ser mayor a 0.");
    }

    public double getPrecioBase() {
        return precioBase;
    }

    public void setPrecioBase(double precioBase) throws Exception {
        if(precioBase > 0)this.precioBase = precioBase;
        else throw new Exception("Ingresa un precio base valido.");
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\nLibro: ").append((!titulo.isBlank() || !titulo.isEmpty()) ? titulo : "Ingrese un titulo valido.");
        sb.append("\nEscritor: ").append((!escritor.isBlank() || !escritor.isEmpty()) ? escritor : "Ingrese escritor.");
        sb.append("\nCoodISBN: ").append((coodISBN.length() == 13) ? coodISBN:"ERROR: Codigo no valido.");
        sb.append("\nEditorial: ").append((!editorial.isBlank() || !editorial.isEmpty()) ? editorial : "Ingrese editorial.");
        sb.append("\nAnho de Publicacion: ").append((anhoPublicacion <= 0) ? "Ingrese un anho valido." : anhoPublicacion);
        sb.append("\nPrecio Base: ").append((precioBase <= 0) ? "Ingrese un Valor." : "$" + precioBase);
        return sb.toString();
    }
    
    
    
    
    
    
    
}
