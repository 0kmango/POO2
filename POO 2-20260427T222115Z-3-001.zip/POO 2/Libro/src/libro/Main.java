
package libro;

import model.Libro;

public class Main {

    public static void main(String[] args) {
        
        Libro l = new Libro("Historia Tomo 1", "Herodoto", "JIDJA8JDK3231", "", 1952, 80000);
        System.out.println(l);
        
        
        Libro l2 = new Libro("Historia Antigua", "Joaquin Sanmartin", "DJIAO88", "Carla Chandia", 1942, 75000);
        System.out.println(l2);

        
        Libro l3 = new Libro("Las flipantes aventuras de Carla Chandia", "La Martina", "JHJ8J3JHAKDJ8", "CUXI", 3021, 120000);
        System.out.println(l3);
        
        Libro l4 = new Libro("", "", "", "", 0, 0);
        System.out.println(l4);
        
        
    }
    
}
