/*

Crear un sistema en el que se optimice los sases y los sises,

REQUISITOS:
Crear una clase alumno;
Crear una clase Profesor;
Hacer que cada alumno se le asigne un profesor;

ATRIBUTOS ALUMNO:
- NOMBRE
- APELLIDO
- EDAD
- CURSO EJ (6-B) - (3-D)
- PROMEDIO NOTAS

ATRIBUTOS PROFESOR
- NOMBRE
- ASIGNATURA
- EDAD
- SUELDO_BASE

VALOR BASE DE PROMEDIO_NOTAS = 7.0

CREAR METODOS:
Calcular_notas()
Calcular_sueldo_anual()

METODO ACCION:
LA CLASE ALUMNO DEBE TENER UN METODO QUE NO SEA TooString(), 
Que diga su (nombre, apellido, edad y que profe tiene asignado)

EJ:
HOLA SOY ELIAS SAN MARTIN TENGO 21 AÑOS
MI PROFE ASIGNADO ES: ALEJANDRO WACOLDO

 */
package mangokiwieliassas;

import model.Alumno;
import model.Profesor;

public class Main {

    public static void main(String[] args) {

        Profesor p = new Profesor("Mario Zapata", "Bases de Innovacion", 46, 130000);
        Profesor p2 = new Profesor("Mabel Reyes", "Base de datos", 48, 125000);
        Profesor p3 = new Profesor("Alejandro Sepulveda", "POO", 35, 430000);
        
        
        Alumno a = new Alumno("Hans ", "Negro Morales", 18, "1-A", 4.7, p);
        Alumno a2 = new Alumno("Martineca ", "Martherian", 21, "3-C", 6.2, p2);
        Alumno a3 = new Alumno("Elias ", "Catrillanca", 22, "4-B", 5.8, p3);

        
        a.calcularNotas(3.5, 5.4, 6.5, 7.0);
        a.mostrar();
        
        System.out.println(p);
        p.calcularSueldoAnual(120000);
        
        
        
        a2.calcularNotas(4.5, 2.4, 3.5, 5.0);
        a2.mostrar();
        
        System.out.println(p2);
        p2.calcularSueldoAnual(145000);
        
        a3.calcularNotas(4.0, 1.4, 2.5, 4.3);
        a3.mostrar();
       
        System.out.println(p3);
        p3.calcularSueldoAnual(323000);
        


        
        
        
        
    }
    
}
