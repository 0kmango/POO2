
package model;

public class Profesor {
    
    private String nombre;
    private String asignatura;
    private int edad;
    private double sueldoBase;

    public Profesor(String nombre, String asignatura, int edad, double sueldoBase) {
        this.nombre = nombre;
        this.asignatura = asignatura;
        this.edad = edad;
        this.sueldoBase = sueldoBase;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if(nombre != null)this.nombre = nombre;
        else throw new IllegalArgumentException("Ingresa Nombre.");
    }

    public String getAsignatura() {
        return asignatura;
    }

    public void setAsignatura(String asignatura) {
        if(asignatura != null)this.asignatura = asignatura;
        else throw new IllegalArgumentException("Ingresa asignatura.");
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        if(edad > 0)this.edad = edad;
        else throw new IllegalArgumentException("Ingresa edad valida");
    }

    public double getSueldoBase() {
        return sueldoBase;
    }

    public void setSueldoBase(double sueldoBase) {
        if(sueldoBase > 0)this.sueldoBase = sueldoBase;
        else throw new IllegalArgumentException("Ingresa un sueldo base valido.");
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\nProfesor: ").append(((nombre == null) ? "Ingresa nombre." : nombre));
        sb.append("\nAsignatura: ").append(((asignatura == null) ? "Ingresa asignatura." : asignatura));
        sb.append("\nEdad: ").append((edad <= 0) ? "Ingresa edad valida." : edad);
        sb.append("\nSueldo Base: ").append(((sueldoBase <= 0) ? "Ingresa un sueldo base." : sueldoBase ));
        return sb.toString();
    }

    /*
    public void mostrar(){
        System.out.println(((nombre == null) ? "Ingresa nombre." : nombre));
        System.out.println(((asignatura == null) ? "Ingresa asignatura." : asignatura));
        System.out.println((edad <= 0) ? "Ingresa edad valida." : edad);
        System.out.println(((sueldoBase <= 0) ? "Ingresa un sueldo base." : sueldoBase ));
    }
    */
    
    public double calcularSueldoAnual(double sueldoAnual){
        sueldoAnual = (this.sueldoBase * 12);
        System.out.println("Sueldo Anual de " + nombre + " es de $" + sueldoAnual);
        return sueldoAnual;
    }
    
    
}
