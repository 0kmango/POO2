
package model;

public final class Alumno {
    
    private String nombre;
    private String apellido;
    private int edad;
    private String curso;
    private double promedioNotas;
    private Profesor profesorAsignado;

    public Alumno(String nombre, String apellido, int edad, String curso, double promedioNotas, Profesor profesorAsignado) {
        this.setNombre(nombre);
        this.setApellido(apellido);
        this.setEdad(edad);
        this.setCurso(curso);
        this.promedioNotas = 7.0;
        this.setProfesorAsignado(profesorAsignado);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if(nombre != null)this.nombre = nombre;
        else throw new IllegalArgumentException("Ingresa nombre.");
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        if(apellido != null)this.apellido = apellido;
        else throw new IllegalArgumentException("Igresa apellido.");
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        if(edad >= 0)this.edad = edad;
        else throw new IllegalArgumentException("Ingresa edad valida");
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        if(curso != null)this.curso = curso;
        else throw new IllegalArgumentException("Igresa curso.");
    }

    public double getPromedioNotas() {
        return promedioNotas;
    }

    public void setPromedioNotas(double promedioNotas) {
        if(promedioNotas > 1.0 && promedioNotas < 7.0)this.promedioNotas = promedioNotas;
        throw new IllegalArgumentException("Ingresa un promedio valido.");
    }

    public Profesor getProfesorAsignado() {
        return profesorAsignado;
    }

    public void setProfesorAsignado(Profesor profesorAsignado) {
        if(profesorAsignado != null)this.profesorAsignado = profesorAsignado;
        else throw new IllegalArgumentException("Ingresa un asigna un profesor.");
    }
    
    
    public void mostrar(){ 
        System.out.println("\nAlumno: " + ((nombre == null) ? "Ingresa nombre." : nombre + apellido));
        System.out.println("Edad: " + ((edad <= 0) ? "Ingresa edad valida." : edad));
        System.out.println("Profesor Asignado: " + ((profesorAsignado == null) ? "Asigna un profesor." : profesorAsignado.getNombre()));  
        System.out.println("Promedio Notas: " + ((promedioNotas < 0 && promedioNotas > 7.0) ? "Ingresa notas validas." : promedioNotas));
    }
    
    public double calcularNotas(double n1,double n2,double n3, double n4){
        this.promedioNotas = (n1 + n2+ n3 + n4) / 4;
        return this.promedioNotas;
    }
    
}
