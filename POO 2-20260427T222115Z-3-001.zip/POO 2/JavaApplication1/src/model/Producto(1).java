
package model;

public class Producto {
    
    private String codigo;
    private String nombre;
    private int precio;
    private int stock;
    private int desc;

    public Producto(String codigo, String nombre, int precio, int stock) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.precio = precio;
        this.stock = stock;
        this.desc = 0;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) throws Exception {
        if (!codigo.isBlank() || !codigo.isEmpty())this.codigo = codigo;
        else throw new Exception("El codigo no puede ser 0.");
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) throws Exception {
        if (!nombre.isEmpty() || !nombre.isBlank())this.nombre = nombre;
        else throw new Exception("El nombre no puede estar vacio.");
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) throws Exception {
        if(precio >= 0)this.precio = precio;
        else throw new Exception("El valor debe ser mayor a 0.");
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock)throws Exception {
        if(stock >= 0)this.stock = stock;
        else throw new Exception("El stock debe ser mayor a 0.");
    }

    public double getDesc() {
        return desc;
    }

    public void setDesc(int desc) throws Exception {
        if(desc >= 0 || desc <= 100)this.desc = desc;
        else throw new Exception("El descuento debe estar entre 0 y 100.");
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\nProducto - ").append(codigo);
        sb.append("\nNombre: ").append(nombre);
        sb.append("\nPrecio: $").append(precio);
        sb.append("\nStock: ").append(stock);
        return sb.toString();
    }

    
    public void precioFinal(int desc){ 
        this.desc = desc;
        double total = this.precio - (this.precio * this.getDesc() / 100);
        System.out.println("Descuento: " + desc + "%");
        System.out.println("Precio final con descuento: $" + total);
    } 
    
    public void comprarProducto(int stock){
        int compra = this.getStock() - stock;
        this.stock = compra;
        System.out.println("Compra realizada stock: " + compra);
    }
    
    public void reponerStock(int stock){
        int compra = this.getStock() - stock;
        int reponer = this.getStock() + (this.stock - compra );
        System.out.println("\nSe han sumando " + stock + " productos al stock");
        System.out.println("El stock se ha repuesto");
        System.out.println("Stock actual: " + reponer);
    }

    
    

    
    
    
}
