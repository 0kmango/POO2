
package TiendaOnline;

import model.Producto;

public class Tienda {

    public static void main(String[] args) {

        Producto p = new Producto("3D5DAH", "NINTENDO", 120000, 12);

        System.out.println(p);
        p.comprarProducto(1);
        p.precioFinal(20);
        p.reponerStock(4);
        
        
        Producto p1 = new Producto("F6S7HF", "PS4 Slim", 350000, 23);
        
        System.out.println(p1);
        p.comprarProducto(1);
        p.precioFinal(30);
        p.reponerStock(5);

        

        
    }
    
}
