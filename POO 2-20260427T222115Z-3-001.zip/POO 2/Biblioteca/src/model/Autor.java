
package model;

public class Autor {
    
    private String nombre;
    private String nacionalidad;
    private int edad;

    public Autor(String nombre, String nacionalidad, int edad) {
        this.nombre = nombre;
        this.nacionalidad = nacionalidad;
        this.edad = edad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) throws Exception {
        if(!nombre.isBlank() || !nombre.isEmpty())this.nombre = nombre;
        else throw new Exception("Ingresa un nombre");
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad)throws Exception {
        if(!nacionalidad.isBlank() || !nacionalidad.isEmpty())this.nombre = nombre;
        else throw new Exception("Ingresa nacionalidad");
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) throws Exception {
        if(edad > 0)this.edad = edad;
        else throw new Exception("Ingrese una edad valida.");
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\nAutor: ").append((!nombre.isBlank() || !nombre.isEmpty()) ? nombre : "Ingrese un nombre.");
        sb.append("\nNacionalidad: ").append((!nacionalidad.isBlank() || !nacionalidad.isEmpty()) ? nacionalidad : "Ingrese nacionalidad.");
        sb.append("\nEdad: ").append((edad <= 0) ? "Ingrese una edad valida" : edad);
        return sb.toString();
    }
    
    
     
    
}
