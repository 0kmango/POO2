
package model;

public class Libro {
    
    private String nombre;
    private String codigoISBN;
    private double precioBase;
    private int stock;
    private String escritor;

    public Libro(String nombre, String codigoISBN, double precioBase, int stock, String escritor) {
        this.nombre = nombre;
        this.codigoISBN = codigoISBN;
        this.precioBase = precioBase;
        this.stock = stock;
        this.escritor = escritor;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) throws Exception {
        if(!nombre.isBlank() || !nombre.isEmpty())this.nombre = nombre;
        else throw new Exception("Ingresa un nombre");
    }

    public String getCodigoISBN() {
        return codigoISBN;
    }

    public void codigoISBN(String codigoISBN) throws Exception {
        if(codigoISBN.length() == 13)this.codigoISBN = codigoISBN;
        else throw new IllegalArgumentException("El codigo debe tener solo 13 caracteres.");
    }

    public double getPrecioBase() {
        return precioBase;
    }

    public void setPrecioBase(double precioBase)throws Exception {
        if(precioBase > 0)this.precioBase = precioBase;
        else throw new Exception("El precio debe ser mayor.");
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) throws Exception {
        if(stock > 0)this.stock = stock;
        else throw new Exception("El stock debe ser mayor.");
    }

    public String getEscritor() {
        return escritor;
    }

    public void setEscritor(String escritor)throws Exception {
        if(!escritor.isBlank() || !escritor.isEmpty())this.escritor = escritor;
        else throw new Exception("Ingresa escritor.");
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\nLibro: ").append((!nombre.isBlank() || !nombre.isEmpty()) ? nombre : "Ingrese un nombre.");
        sb.append("\nCodigoISBN: ").append((codigoISBN.length() == 13) ? codigoISBN:"ERROR: Codigo no valido. Debe tener 13 caracteres.");;
        sb.append("\nPrecio Base: $").append((precioBase < 0) ? "El precio debe ser mayor a 0." : precioBase);
        sb.append("\nStock: ").append((stock < 0) ? "El Stock debe ser mayor a 0." : stock);
        sb.append("\nEscritor: ").append((!escritor.isBlank() || !escritor.isEmpty()) ? escritor : "Ingrese escritor.");
        return sb.toString();
    }
    
    public void prestar(int stock){
        int prestamo = this.getStock() - stock;
        this.stock = prestamo;
        System.out.println("\nSe han prestado " + prestamo + " libros: "+ nombre);
        System.out.println("El stock actual de " +nombre + " es " + stock);
    }
    
    public void devolver(int stock){
        int prestamo = this.getStock() - stock;
        int devuelto = this.getStock() + (this.stock - prestamo );
        System.out.println("\nSe han devuelto " + stock + " libros " + nombre + " al stock");
        System.out.println("El stock se ha repuesto");
        System.out.println("El stock actual de " +nombre + " es " + devuelto);
    }
    
    public double calcularValoracionStock(){
        double valoracion;
        valoracion = this.precioBase * this.stock * 0.5;
        System.out.println("\nEl valor por stock del libro " + nombre + " es: $" + valoracion);
        return valoracion;
        
    }
    
    
    
    
}