
package mangokiwi;

import model.Autor;
import model.Libro;

public class Main {

    public static void main(String[] args) {
        
        System.out.println("\n=============== LIBROS ===============");

        Libro lib = new Libro("Rebelion en la Granja", "JD8A98D", 20000, 16, "George Orwell");
        Autor au = new Autor("George Orwell", "Inglesa", 177);
        System.out.println(lib);
        lib.calcularValoracionStock();
        System.out.println(au);
        
        Libro lib2 = new Libro("Corazon Delator", "JA8JUW67HDYA6", 22000, 15, "Edgar Allan Poe");
        Autor au2 = new Autor("Edgar Allan Poe", "Estadounidense", 76);
        System.out.println(lib2);
        lib2.calcularValoracionStock();
        System.out.println(au2);

        
        System.out.println("\n=============== Prestamos y Devoluciones ===============\n");

        
        lib.prestar(7);
        lib2.prestar(9);

        lib.devolver(2);
        lib2.devolver(4);
        
        lib.calcularValoracionStock();
        
    }
    
}
