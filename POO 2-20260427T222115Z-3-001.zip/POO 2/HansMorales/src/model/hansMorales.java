package model;

public class hansMorales {

    private String nombre;
    private String apellido;
    private int edad;
    private boolean tienePiernas;
    private boolean tieneBrazos;

    public hansMorales(String nombre, String apellido, int edad, boolean tienePiernas, boolean tieneBrazos) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.tienePiernas = tienePiernas;
        this.tieneBrazos = tieneBrazos;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) throws Exception {
        if (!nombre.isBlank() || !nombre.isEmpty()) {
            this.nombre = nombre;
        } else {
            throw new Exception("Debes ingresar un nombre.");
        }
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) throws Exception {
        if (!apellido.isBlank() || !apellido.isEmpty()) {
            this.apellido = apellido;
        } else {
            throw new Exception("Debes ingresar un apellido.");
        }
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) throws Exception {
        if (edad < 0) {
            System.out.println("Aun no naces.");

        } else if (edad > 100) {
            System.out.println("Estas muerto necrosado.");

        } else ;
        this.edad = edad;
    }

    public boolean isTienePiernas() {
        return tienePiernas;
    }

    public void setTienePiernas(boolean tienePiernas) {
        if (tienePiernas) {
            this.tienePiernas = tienePiernas;
            System.out.println("Si, tienes piernas eres un humano normal.");
        } else {
            System.out.println("Mo, no tienes piernas anormal de mierda.");
        }
    }

    public boolean isTieneBrazos() {
        return tieneBrazos;
    }

    public void setTieneBrazos(boolean tieneBrazos) {
        if (tieneBrazos) {
            this.tieneBrazos = tieneBrazos;
            System.out.println("Si, tienes brazos eres un humano normal.");
        } else {
            System.out.println("No, no tienes brazos anormal de mierda.");
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\nNombre: ").append(nombre);
        sb.append("\nApellido: ").append(apellido);
        sb.append("\nEdad: ").append(edad + " - ").append((edad < 0) ? "Aun no naces feto abortado." : (edad > 100) ? "Estas muerto necrosado." : edad);
        sb.append("\nTiene Piernas: ").append(tienePiernas ? "Si, tienes piernas eres un humano normal y perfecto." : "No, no tienes piernas anormal de mierda cojo.");
        sb.append("\nTiene Brazos: ").append(tieneBrazos ? "Si, tienes brazos eres un humano normal y perfecto." : "No, no tienes brazos anormal de mierda manco.");
        return sb.toString();
    }
    
    public void accion1(){
        System.out.println(nombre + " se toca en publico y asusta a los ninhos.");
    }
    
    public void accion2(){
        System.out.println(nombre + " se convierte en therian y huele el oyo de animales callejeros.");
    }

}
