
package hans;

import model.hansMorales;

public class hans {

    public static void main(String[] args) {
        
        hansMorales h1 = new hansMorales("Negro", "Morales", 301, true, false);
        
        System.out.println(h1);
        h1.accion1();
        
        hansMorales h2 = new hansMorales("Janz", "Furro Morales", 0, false, true);
        
        System.out.println(h2);
        h2.accion2();
        

        
    }
    
}
