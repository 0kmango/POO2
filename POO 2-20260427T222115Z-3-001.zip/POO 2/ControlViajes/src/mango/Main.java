
package mango;

import model.Conductor;
import model.Vehiculo;
import model.Viaje;

public class Main {

    public static void main(String[] args) {

        Vehiculo ve = new Vehiculo("H77HA6H3", "MITSUBISHI", "LANCER",7);
        Vehiculo ve2 = new Vehiculo("JJU73Y", "SUBARU", "IMPREZA", 10);
        
        Conductor c = new Conductor("Wacoldo Lopez", true, 2);
        Conductor c2 = new Conductor("Wacoldia Sanchez", false, 7);
        
        Viaje vi = new Viaje("JHS723J8", ve, c2, 23, 4000);
        Viaje vi2 = new Viaje("KKSJ771223", ve2, c, 8, 5000);
        
        System.out.println(vi);
        System.out.println("Costo de viaje: " + String.format("%.2f",vi.calcularCostoViaje()));
        System.out.println("Consumo de combustible: " + String.format("%.2f",vi.calcularConsumoCombustible()));
        
        System.out.println(vi2);
        System.out.println("Costo de viaje: " + String.format("%.2f",vi2.calcularCostoViaje()));
        System.out.println("Consumo de combustible: " + String.format("%.2f",vi2.calcularConsumoCombustible()));

        
        
        
    }
    
}
