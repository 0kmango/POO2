
package model;

public class Conductor {
    
    private String nombre;
    private boolean licencia;
    private int anhosExp;

    public Conductor(String nombre, boolean licencia, int anhosExp) {
        this.nombre = nombre;
        this.licencia = licencia;
        this.anhosExp = anhosExp;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if(!nombre.isBlank() || !nombre.isEmpty() || nombre != null)this.nombre = nombre;
        else throw new IllegalArgumentException("Ingrese nombre valido.");
    }

    public boolean isLicencia() {
        return licencia;
    }

    public void setLicencia(boolean licencia) {
        this.licencia = licencia;
    }

    public int getAnhosExp() {
        return anhosExp;
    }

    public void setAnhosExp(int anhosExp) {
        if(anhosExp >= 0)this.anhosExp = anhosExp;
        else throw new IllegalArgumentException("Ingresa fecha valida.");
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\nConductor: ").append((!nombre.isBlank() || !nombre.isEmpty()) ? nombre : "Ingresa nombre.");
        sb.append("\nLicencia: ").append((licencia == true) ? "Tiene Licencia." : "No posee licencia.");
        sb.append("\nAnhosExp: ").append((anhosExp <= 0) ? "Ingrese una fecha valida" : anhosExp);
        return sb.toString();
    }
    
    
    
    
}
