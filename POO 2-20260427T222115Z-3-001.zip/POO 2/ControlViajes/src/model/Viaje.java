package model;

public class Viaje {

    private String codViaje;
    private Vehiculo vehiculo;
    private Conductor conductor;
    private double distancia;
    private double costxKm;

    public Viaje(String codViaje, Vehiculo vehiculo, Conductor conductor, double distancia, double costxKm) {
        this.codViaje = codViaje;
        this.vehiculo = vehiculo;
        this.conductor = conductor;
        this.distancia = distancia;
        this.costxKm = costxKm;
    }

    public String getCodViaje() {
        return codViaje;
    }

    public void setCodViaje(String codViaje) {
        if (!codViaje.isBlank() || !codViaje.isEmpty() || codViaje != null && codViaje.length() == 8) {
            this.codViaje = codViaje;
        } else {
            throw new IllegalArgumentException("Ingrese codigo valido.");
        }
    }

    public Vehiculo getVehiculo() {
        return vehiculo;
    }

    public void setVehiculo(Vehiculo vehiculo) {
        this.vehiculo = vehiculo;
    }

    public Conductor getConductor() {
        return conductor;
    }

    public void setConductor(Conductor conductor) {
        this.conductor = conductor;
    }

    public double getDistancia() {
        return distancia;
    }

    public void setDistancia(double distancia) {
        if (distancia > 0) {
            this.distancia = distancia;
        } else {
            throw new IllegalArgumentException("Ingresa distancia valida.");
        }
    }

    public double getCostxKm() {
        return costxKm;
    }

    public void setCostxKm(double costxKm) {
        if (costxKm >= 0) {
            this.costxKm = costxKm;
        } else {
            throw new IllegalArgumentException("Ingresa costo valido.");
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\nViaje: ").append((codViaje.length() == 8) ? codViaje : "Ingresa codigo de viaje.");
        sb.append("").append(vehiculo);
        sb.append("").append(conductor);
        sb.append("\nDistancia: ").append((distancia >= 0) ? distancia : "Ingrese distancia.");
        sb.append("\nCosto por Km: $").append((costxKm >= 0) ? costxKm : "Ingrese costo.");
        return sb.toString();
    }

    public double calcularCostoViaje() {

        double costoBase;
        costoBase = this.getDistancia() * this.getCostxKm();

        double cargo;
        if (distancia >= 100) {
            cargo = costoBase * 1.10;
        } else {
            cargo = costoBase;
        }

        double costoFinal;
        if (conductor.getAnhosExp() >= 5) {
            costoFinal = cargo * 0.95;
        }else{
            costoFinal = costoBase;
        }
         return costoFinal;
    }    

    public double calcularConsumoCombustible() {

        double consumoBase;
        consumoBase = this.getDistancia() * this.vehiculo.getConsumoComb();
        
        double consumoAjustado;
        if(this.conductor.getAnhosExp() < 5){
            consumoAjustado = consumoBase * 1.12;
        }else{
            consumoAjustado = consumoBase;
        }
        return consumoAjustado;
    }

}
