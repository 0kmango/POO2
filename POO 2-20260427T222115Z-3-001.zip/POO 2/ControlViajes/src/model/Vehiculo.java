
package model;

public class Vehiculo {
    
    private String patente;
    private String marca;
    private String modelo;
    private double consumoComb;

    public Vehiculo(String patente, String marca, String modelo, double consumoComb) {
        this.patente = patente;
        this.marca = marca;
        this.modelo = modelo;
        this.consumoComb = consumoComb;
    }

    public String getPatente() {
        return patente;
    }

    public void setPatente(String patente) {
        if(!patente.isBlank() || !patente.isEmpty() || patente != null && patente.length() == 6)this.patente = patente;
        else throw new IllegalArgumentException("Ingrese patente valida.");
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public double getConsumoComb() {
        return consumoComb;
    }

    public void setConsumoComb(double consumoComb) {
        if(consumoComb >= 0)this.consumoComb = consumoComb;
        else throw new IllegalArgumentException("Ingresa consumo valido.");
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\nVehiculo: ").append((patente.length() == 6) ? patente : "Ingrese patente valida.");
        sb.append("\nMarca: ").append((!marca.isBlank() || !marca.isEmpty()) ? marca : "Ingresa marca.");
        sb.append("\nModelo: ").append((!modelo.isBlank() || !modelo.isEmpty()) ? modelo : "Ingresa modelo.");
        sb.append("\nConsumo Combustible: ").append((consumoComb >= 0) ? consumoComb : "Ingrese consumo.");
        return sb.toString();
    }
    
    
    
    
}
