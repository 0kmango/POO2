
package norambuena_martina_parcial_1;

import model.Habitacion;
import model.Huesped;
import model.Reserva;

public class Main {

    public static void main(String[] args) {

        Habitacion ha = new Habitacion(13, "suite", 1200000);
        Habitacion ha2 = new Habitacion(10, "doble", 120000);
        
        Huesped hue = new Huesped("Pancho Saavedra", "13535053-K", true);
        Huesped hue2 = new Huesped("Ernesto Sabato", "77765687-0", false);
        
        Reserva re = new Reserva("HD7Y2K", ha, hue, 3, 2);
        Reserva re2 = new Reserva("BP3JU2", ha2, hue2, 6, 3);
 
        
        re.info();
        
        System.out.println("\nHUESPED: " + re2.getHuesped().getNombre());
        System.out.println("CANTIDAD DE NOCHES: " + re2.getCantNoches());
        re2.setCantNoches(9);
        System.out.println("NUEVA CANTIDAD DE NOCHES: " + re2.getCantNoches());
        
        re2.info();
        
        
        
    }
    
}
