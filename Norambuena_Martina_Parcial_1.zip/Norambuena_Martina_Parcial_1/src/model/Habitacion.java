
package model;

public class Habitacion {
    
    private int numHabitacion;
    private String tipoHabitacion;
    private double precioBasexNoche;

    public Habitacion(int numHabitacion, String tipoHabitacion, double precioBasexNoche) {
        this.numHabitacion = numHabitacion;
        this.tipoHabitacion = tipoHabitacion;
        this.precioBasexNoche = precioBasexNoche;
    }


    public int getNumHabitacion() {
        return numHabitacion;
    }

    public void setNumHabitacion(int numHabitacion) {
        this.numHabitacion = numHabitacion;
    }

    public String getTipoHabitacion() {
        return tipoHabitacion;
    }

    public void setTipoHabitacion(String tipoHabitacion) {
        this.tipoHabitacion = tipoHabitacion;
    }

    public double getPrecioBasexNoche() {
        return precioBasexNoche;
    }

    public void setPrecioBasexNoche(double precioBasexNoche) {
        if(precioBasexNoche >= 0)this.precioBasexNoche = precioBasexNoche;
        else throw new IllegalArgumentException("Ingrese un valor mayor");
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\nHabitacion: ").append(numHabitacion);
        sb.append("\nTipo Habitacion: ").append(tipoHabitacion);
        sb.append("\nPrecioBasexNoche: ").append((precioBasexNoche >= 0) ? precioBasexNoche : "Ingrese un valor mayor.");
        return sb.toString();
    }
    
    
    
    
    
    
    
    
}
