package model;

public class Reserva {

    private String codReserva;
    private Habitacion habitacion;
    private Huesped huesped;
    private int cantNoches;
    private int cantPersonas;

    public Reserva(String codReserva, Habitacion habitacion, Huesped huesped, int cantNoches, int cantPersonas) {
        this.codReserva = codReserva;
        this.habitacion = habitacion;
        this.huesped = huesped;
        this.cantNoches = cantNoches;
        this.cantPersonas = cantPersonas;
    }

    public String getCodReserva() {
        return codReserva;
    }

    public void setCodReserva(String codReserva) {
        if (!codReserva.isBlank() && !codReserva.isEmpty()) {
            this.codReserva = codReserva;
        } else {
            throw new IllegalArgumentException("Ingrese codigo.");
        }
    }

    public Habitacion getHabitacion() {
        return habitacion;
    }

    public void setHabitacion(Habitacion habitacion) {
        this.habitacion = habitacion;
    }

    public Huesped getHuesped() {
        return huesped;
    }

    public void setHuesped(Huesped huesped) {
        this.huesped = huesped;
    }

    public int getCantNoches() {
        return cantNoches;
    }

    public void setCantNoches(int cantNoches) {
        if (cantNoches > 0) {
            this.cantNoches = cantNoches;
        } else {
            throw new IllegalArgumentException("Ingrese cantidad de noches.");
        }
    }

    public int getCantPersonas() {
        return cantPersonas;
    }

    public void setCantPersonas(int cantPersonas) {
        if (cantPersonas >= 0) {
            this.cantPersonas = cantPersonas;
        } else {
            throw new IllegalArgumentException("Ingrese una cantidad valida.");
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\nReserva: ").append((codReserva == null || codReserva.length() != 6) ? "Ingrese codigo valido." : codReserva);
        sb.append(habitacion);
        sb.append(huesped);
        sb.append("\nCantidad Noches: ").append((cantNoches > 0) ? cantNoches : "Ingrese una cantidad mayor.");
        sb.append("\nCantidad Personas: ").append((cantPersonas >= 0) ? cantPersonas : "Ingrese cantidad valida.");
        return sb.toString();
    }

    public double calcularCostoTotal() {

        double costoBase;
        costoBase = this.getCantNoches() * this.habitacion.getPrecioBasexNoche();

        double descVip;
        if (this.huesped.isClienteVip() == true) {
            descVip = costoBase * 0.9;
        } else { 
            descVip = costoBase;
        }

        double costoFinal;
        costoFinal = costoBase * 0.90;

        return costoFinal;

    }
    
    
    public void info(){
        System.out.println("CODIGO DE RESERVA: "+ codReserva);
        System.out.println("NOMBRE DEL HUESPED: " + this.huesped.getNombre());
        System.out.println("NUMERO DE HABITACION: " + this.habitacion.getNumHabitacion());
        System.out.println("COSTO TOTAL DE LA RESERVA: " + this.habitacion.getPrecioBasexNoche());
    }
    

}
