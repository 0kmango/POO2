
package model;

public class Huesped {
    
    private String nombre;
    private String rut;
    private boolean clienteVip;

    public Huesped(String nombre, String rut, boolean clienteVip) {
        this.nombre = nombre;
        this.rut = rut;
        this.clienteVip = clienteVip;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if(!nombre.isBlank() && !nombre.isEmpty())this.nombre = nombre;
        else throw new IllegalArgumentException("Ingrese nombre.");
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        if(!rut.isBlank() && !rut.isEmpty())this.rut = rut;
        else throw new IllegalArgumentException("Ingrese rut.");
    }

    public boolean isClienteVip() {
        return clienteVip;
    }

    public void setClienteVip(boolean clienteVip) {
        this.clienteVip = clienteVip;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\nHuesped: ").append((nombre == null) ? "Ingrese nombre." : nombre);
        sb.append("\nRut: ").append((rut == null || rut.length() != 10) ? "Ingrese rut valido." : rut);
        sb.append("\nCliente Vip: ").append(clienteVip);
        return sb.toString();
    }
    
    
    
    
    
}
